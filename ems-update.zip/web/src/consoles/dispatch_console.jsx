import React, { useState, useEffect, useMemo, useRef } from "react";
import { openCallDraft, setCallNearHint, formFromIncident } from "./call_form.jsx";
import { useLeafletLoader, esc as escMap, hasFix as mapHasFix, effectivePosition, fetchRoute, PICKUP_COLOR, DROPOFF_COLOR, QUEUED_COLOR } from "./map_kit.jsx";
import {
  CheckCircle2,
  Navigation,
  MapPin,
  Truck,
  XCircle,
  Plus,
  X,
  Radio,
  Activity,
  AlertTriangle,
  Wifi,
  WifiOff,
} from "lucide-react";

const HAIRLINE = "#232C3A";
const PANEL = "#131A24";
const VOID = "#0A0E13";
const SUNKEN = "#0D131B";
const TEXT_PRIMARY = "#E7ECF2";
const TEXT_SECONDARY = "#A9B6C6";
const TEXT_FAINT = "#8795AB";
const BLUE = "#4EA1F0";
const AMBER = "#F5934A";
const GREEN = "#34D399";
const RED = "#F0554A";

const MAP_BOUNDS = { latMin: 40.795, latMax: 40.90, lonMin: -73.945, lonMax: -73.835 };

const STATUS_CONFIG = {
  available: { label: "Available", color: "#34D399", icon: CheckCircle2 },
  assigned: { label: "Assigned", color: "#F5A623", icon: Radio },
  en_route: { label: "En Route", color: "#F0862B", icon: Navigation },
  on_scene: { label: "On Scene", color: "#4EA1F0", icon: MapPin },
  transporting: { label: "Transporting", color: "#6C7FF0", icon: Truck },
  at_destination: { label: "At Destination", color: "#5EEAD4", icon: Activity },
  out_of_service: { label: "Out of Service", color: "#55627A", icon: XCircle },
};

const PRIORITY_CONFIG = {
  critical: { label: "Critical", color: "#F0554A", targetMin: 8, rank: 0 },
  emergent: { label: "Emergent", color: "#F5934A", targetMin: 12, rank: 1 },
  urgent: { label: "Urgent", color: "#EAC54F", targetMin: 20, rank: 2 },
  routine: { label: "Routine", color: "#6B7A90", targetMin: 60, rank: 3 },
};

// Matches the schema's actual incident_type enum — "911" alone was
// the frontend's own shorthand and never matched what the database
// accepts, caught only once real wiring made that mismatch load-bearing.
const TYPE_LABELS = {
  emergency_911: "911 Emergency",
  ift_scheduled: "IFT — Scheduled",
  ift_on_demand: "IFT — On Demand",
};

const ROLE_LABELS = { primary: "Primary", als_intercept: "ALS Intercept", support: "Support" };
const CREW_LABELS = { driver: "Driver", non_driver: "Non-Driver" };

// ---- Geography helpers -------------------------------------------------
function haversineMiles(a, b) {
  const R = 3958.8;
  const toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}
function estimateEtaMinutes(miles) {
  const roadFactor = 1.3;
  const avgSpeedMph = 25;
  return ((miles * roadFactor) / avgSpeedMph) * 60;
}
function project(lat, lon) {
  const x = ((lon - MAP_BOUNDS.lonMin) / (MAP_BOUNDS.lonMax - MAP_BOUNDS.lonMin)) * 100;
  const y = (1 - (lat - MAP_BOUNDS.latMin) / (MAP_BOUNDS.latMax - MAP_BOUNDS.latMin)) * 100;
  return { x, y };
}
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const TOMTOM_KEY = import.meta.env?.VITE_TOMTOM_KEY || "";

function formatElapsed(ms) {
  const totalSec = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const pad = (n) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}
function fetchRoutedDistance(from, to) {
  const jitterMs = Math.random() * 600;
  return new Promise((resolve, reject) => {
    setTimeout(async () => {
      try {
        const url = `https://router.project-osrm.org/route/v1/driving/${from.lon},${from.lat};${to.lon},${to.lat}?overview=false`;
        const res = await fetch(url);
        if (!res.ok) throw new Error("routing request failed");
        const data = await res.json();
        if (data.code !== "Ok" || !data.routes?.[0]) throw new Error("no route returned");
        resolve({ miles: data.routes[0].distance / 1609.34, etaMin: data.routes[0].duration / 60 });
      } catch (e) {
        reject(e);
      }
    }, jitterMs);
  });
}
function useRoutedEta(unit, incident) {
  const [routed, setRouted] = useState(null);
  const [status, setStatus] = useState("idle");
  useEffect(() => {
    if (!unit || unit.lat == null || unit.lon == null || incident.lat == null || incident.lon == null) {
      setRouted(null);
      setStatus("idle");
      return;
    }
    let cancelled = false;
    setStatus("loading");
    fetchRoutedDistance({ lat: unit.lat, lon: unit.lon }, { lat: incident.lat, lon: incident.lon })
      .then((r) => { if (!cancelled) { setRouted(r); setStatus("live"); } })
      .catch(() => { if (!cancelled) { setRouted(null); setStatus("fallback"); } });
    return () => { cancelled = true; };
  }, [unit?.id, incident.id]);
  return { routed, status };
}

// ---- Real API client ----------------------------------------------------
// Mirrors api-client.js exactly (that file is the tested, standalone
// version of this same logic) — inlined here because a single-file
// React artifact can't import a sibling module.
function makeApiRequest(baseUrl, token) {
  return async function request(method, path, body) {
    const res = await fetch(`${baseUrl}${path}`, {
      method,
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const error = new Error(data?.error || `Request failed with HTTP ${res.status}`);
      error.status = res.status;
      throw error;
    }
    return data;
  };
}

function normalizeApiUnit(u) {
  return {
    id: u.unit_id,
    designation: u.unit_designation,
    capability: u.capability_level,
    crew: u.crew || [],
    status: u.current_status,
    lat: u.lat,
    lon: u.lon,
    locationUpdatedAt: u.location_updated_at || null,
    vehicleNumber: u.vehicle_number || null,
    vehicleStatus: u.vehicle_status || null,
  };
}

// The schema has no capability_needed column on incidents at all —
// a real gap, not something a frontend normalizer can properly fix.
// This heuristic (critical/emergent implies ALS) is a stand-in, not a
// substitute for that column actually existing.
function inferCapabilityNeeded(apiIncident) {
  return apiIncident.priority === "critical" || apiIncident.priority === "emergent" ? "ALS" : "BLS";
}

function normalizeApiIncident(i) {
  return {
    id: i.incident_id,
    type: i.incident_type,
    priority: i.priority,
    address: i.scene_address,
    detail: i.scene_detail || "",
    destination: i.destination_text || "",
    patientName: i.patient_name || "",
    contactName: i.contact_name || "",
    contactPhone: i.contact_phone || "",
    notes: i.notes || "",
    capabilityNeeded: i.capability_needed || inferCapabilityNeeded(i),
    callReceivedAt: new Date(i.call_received_at),
    // The API returns each incident's active assignments.
    assignedUnits: (i.assigned_units || []).map((a) => ({ unitId: a.unitId, role: a.role })),
    lat: i.lat,
    lon: i.lon,
    destLat: i.dest_lat,
    destLon: i.dest_lon,
    destinationFacilityId: i.destination_facility_id || null,
  };
}

function makeInitialUnits() {
  return [
    { id: "u1", designation: "Unit 3", capability: "BLS", crew: [{ employeeId: "4471", name: "Marcus Alvarez", role: "driver", cert: "EMT" }, { employeeId: "4502", name: "Emily Chen", role: "non_driver", cert: "EMT" }], status: "available", lat: 40.812, lon: -73.918 },
    { id: "u2", designation: "Unit 7", capability: "ALS", crew: [{ employeeId: "4318", name: "Priya Patel", role: "driver", cert: "EMT" }, { employeeId: "4390", name: "Kwame Osei", role: "non_driver", cert: "Medic" }], status: "en_route", lat: 40.848, lon: -73.879 },
    { id: "u3", designation: "Unit 12", capability: "BLS", crew: [{ employeeId: "4275", name: "Linh Nguyen", role: "driver", cert: "EMT" }, { employeeId: "4601", name: "Tyler Brooks", role: "non_driver", cert: "EMT" }], status: "on_scene", lat: 40.8625, lon: -73.8973 },
    { id: "u4", designation: "Unit 5", capability: "ALS", crew: [{ employeeId: "4188", name: "Fatou Diallo", role: "driver", cert: "Medic" }, { employeeId: "4529", name: "Sean Fitzgerald", role: "non_driver", cert: "EMT" }], status: "available", lat: 40.822, lon: -73.867 },
    { id: "u5", designation: "Unit 9", capability: "BLS", crew: [{ employeeId: "4356", name: "Carlos Reyes", role: "driver", cert: "EMT" }, { employeeId: "4442", name: "Daniel Cho", role: "non_driver", cert: "EMT" }], status: "transporting", lat: 40.858, lon: -73.851 },
    { id: "u6", designation: "Unit 14", capability: "ALS", crew: [{ employeeId: "4213", name: "Chidi Okafor", role: "driver", cert: "EMT" }, { employeeId: "4567", name: "Maria Santos", role: "non_driver", cert: "Medic" }], status: "available", lat: 40.849, lon: -73.86 },
    { id: "u7", designation: "Unit 2", capability: "BLS", crew: [], status: "out_of_service", lat: 40.812, lon: -73.886 },
    { id: "u8", designation: "Unit 21", capability: "ALS", crew: [{ employeeId: "4489", name: "Jason Kim", role: "driver", cert: "EMT" }, { employeeId: "4304", name: "Elena Vasquez", role: "non_driver", cert: "Medic" }], status: "at_destination", lat: 40.8804, lon: -73.8799 },
  ];
}

function makeInitialIncidents(nowMs) {
  return [
    { id: "i1", type: "emergency_911", priority: "critical", address: "Bruckner Expwy & Longwood Ave", capabilityNeeded: "ALS", callReceivedAt: new Date(nowMs - 3 * 60 * 1000), assignedUnits: [], lat: 40.816, lon: -73.896 },
    { id: "i2", type: "emergency_911", priority: "emergent", address: "Fordham Rd & Grand Concourse", capabilityNeeded: "BLS", callReceivedAt: new Date(nowMs - 6 * 60 * 1000), assignedUnits: [{ unitId: "u3", role: "primary" }], lat: 40.8625, lon: -73.8973 },
    { id: "i3", type: "ift_scheduled", priority: "routine", address: "Jacobi Medical Center → 233rd St residence", capabilityNeeded: "BLS", callReceivedAt: new Date(nowMs - 14 * 60 * 1000), assignedUnits: [], lat: 40.8566, lon: -73.8472 },
    { id: "i4", type: "ift_on_demand", priority: "urgent", address: "Montefiore Moses → SNF, Pelham Pkwy", capabilityNeeded: "BLS", callReceivedAt: new Date(nowMs - 9 * 60 * 1000), assignedUnits: [], lat: 40.8804, lon: -73.8799 },
    { id: "i5", type: "emergency_911", priority: "critical", address: "Westchester Ave & Southern Blvd", capabilityNeeded: "ALS", callReceivedAt: new Date(nowMs - 1 * 60 * 1000), assignedUnits: [{ unitId: "u2", role: "primary" }], lat: 40.822, lon: -73.891 },
  ];
}

// Does this unit's level of care satisfy what the call needs?
const meetsLevel = (u, need) => need === "BLS" || (need === "ALS" && (u.capability === "ALS" || u.capability === "CCT")) || (need === "CCT" && u.capability === "CCT");
const hasFix = (o) => o && o.lat != null && o.lon != null;

function nearestOf(pool, incident) {
  if (pool.length === 0) return null;
  // Live data can lack coordinates: a unit that hasn't reported a GPS
  // fix, an incident that was never pinned. Don't rank on NaN.
  const ranked = hasFix(incident) ? pool.filter(hasFix) : [];
  const unit = ranked.length > 0
    ? ranked.reduce((b, u) => (haversineMiles(u, incident) < haversineMiles(b, incident) ? u : b))
    : pool[0];
  const miles = hasFix(incident) && hasFix(unit) ? haversineMiles(unit, incident) : null;
  return { unit, miles, etaMin: miles == null ? null : estimateEtaMinutes(miles) };
}

// A SUGGESTION, never an assignment. `best` is the nearest crewed unit that is
// free right now. `soon` is a unit that is finishing a call (at the
// destination) and is meaningfully closer, worth knowing about before
// sending something farther away.
function getRecommendation(incident, units) {
  const crewed = units.filter((u) => u.crew.length > 0);
  const free = crewed.filter((u) => u.status === "available");
  const exact = free.filter((u) => meetsLevel(u, incident.capabilityNeeded));
  const pool = exact.length > 0 ? exact : free;
  const best = nearestOf(pool, incident);
  const finishing = nearestOf(crewed.filter((u) => u.status === "at_destination" && meetsLevel(u, incident.capabilityNeeded)), incident);
  const soon = finishing && (!best || (finishing.miles != null && best.miles != null && finishing.miles + 0.5 < best.miles)) ? finishing : null;
  if (!best && !soon) return null;
  const hasPrimary = incident.assignedUnits.some((a) => a.role === "primary");
  let role = "support";
  if (!hasPrimary) {
    role = "primary";
  } else if (best && incident.capabilityNeeded === "ALS" && best.unit.capability === "ALS") {
    const primaryAssignment = incident.assignedUnits.find((a) => a.role === "primary");
    const primaryUnit = units.find((u) => u.id === primaryAssignment?.unitId);
    if (primaryUnit && primaryUnit.capability === "BLS") role = "als_intercept";
  }
  return { best, soon, isMismatch: Boolean(best) && pool !== exact, role };
}

// `session` comes from the sign-in screen. Signed in: `live`, real data only,
// never a demo fallback. "View demo": sample data that is never saved anywhere.
// With no session at all (tests) it behaves as the demo.
export default function DispatchConsole({ session }) {
  const live = session?.mode === "live";
  const apiBaseUrl = live ? session.apiBaseUrl : "";
  const apiToken = live ? session.token : "";
  const [loaded, setLoaded] = useState(false);
  const [units, setUnits] = useState(() => (live ? [] : makeInitialUnits()));
  const [now, setNow] = useState(() => new Date());
  const [incidents, setIncidents] = useState(() => (live ? [] : makeInitialIncidents(Date.now())));
  const [connectionStatus, setConnectionStatus] = useState(live ? "connecting" : "demo"); // demo | connecting | live | failed
  const [actionError, setActionError] = useState("");
  const [selIncidentId, setSelIncidentId] = useState(null);
  const [selUnitId, setSelUnitId] = useState(null);
  const [queueFilter, setQueueFilter] = useState("all"); // all | needs | covered
  const [unitFilter, setUnitFilter] = useState("all");   // all | available | oncall | out

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (live) { setLoaded(true); return; } // real data is never cached in the browser
    let cancelled = false;
    (async () => {
      try {
        const res = await window.storage.get("dispatch-console-state", false);
        if (!cancelled && res && res.value) {
          const parsed = JSON.parse(res.value);
          if (parsed.units) setUnits(parsed.units);
          if (parsed.incidents) {
            setIncidents(parsed.incidents.map((i) => ({ ...i, callReceivedAt: new Date(i.callReceivedAt), assignedUnits: i.assignedUnits || [] })));
          }
        }
      } catch (err) {
        // No saved session yet, or storage unavailable — keep defaults.
      } finally {
        if (!cancelled) setLoaded(true);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!loaded || live) return;
    window.storage.set("dispatch-console-state", JSON.stringify({ units, incidents }), false).catch(() => {});
  }, [units, incidents, loaded, live]);

  const apiRequest = useMemo(() => (apiBaseUrl ? makeApiRequest(apiBaseUrl, apiToken) : null), [apiBaseUrl, apiToken]);

  async function refreshFromApi() {
    if (!apiRequest) return;
    const [apiUnits, apiIncidents] = await Promise.all([apiRequest("GET", "/units"), apiRequest("GET", "/incidents")]);
    setUnits(apiUnits.map(normalizeApiUnit));
    setIncidents(apiIncidents.filter((i) => !i.closed_at).map(normalizeApiIncident));
  }

  useEffect(() => {
    if (!loaded) return;
    if (!apiBaseUrl || !apiToken) {
      setConnectionStatus("demo");
      return;
    }
    let cancelled = false;
    setConnectionStatus("connecting");
    refreshFromApi()
      .then(() => { if (!cancelled) setConnectionStatus("live"); })
      .catch((e) => { if (!cancelled) { setConnectionStatus("failed"); setActionError("Could not connect: " + (e.message || "network error")); } });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded, apiBaseUrl, apiToken]);

  // A dispatch board has to move on its own: crews change status and send
  // GPS from other devices. Refresh every 10 seconds while the tab is open.
  useEffect(() => {
    if (connectionStatus !== "live" || !apiRequest) return;
    const t = setInterval(() => {
      if (document.visibilityState === "visible") refreshFromApi().catch(() => {});
    }, 10000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connectionStatus, apiRequest]);

  // The shared seam every write action goes through: call the real API
  // and reload canonical state on success, or fall back to a purely
  // local update when there's nothing to connect to. Deliberately does
  // NOT fall back silently on a failed API call while "live" — that
  // would make a failed action look like it succeeded.
  async function performAction(apiCall, localUpdate) {
    if (live) {
      // Signed in: only the real API. A local fake update here would make
      // a failed action look like it worked.
      try {
        await apiCall();
        await refreshFromApi();
      } catch (e) {
        setActionError(e.message || "Action failed");
      }
      return;
    }
    localUpdate();
  }

  const availableCount = units.filter((u) => u.status === "available").length;
  const activeIncidents = useMemo(
    () =>
      [...incidents].sort((a, b) => {
        const pr = PRIORITY_CONFIG[a.priority].rank - PRIORITY_CONFIG[b.priority].rank;
        return pr !== 0 ? pr : a.callReceivedAt - b.callReceivedAt;
      }),
    [incidents]
  );

  function handleStatusChange(unitId, newStatus) {
    performAction(
      () => apiRequest("PATCH", `/units/${unitId}/status`, { status: newStatus }),
      () => setUnits((prev) => prev.map((u) => (u.id === unitId ? { ...u, status: newStatus } : u)))
    );
  }
  function handleAssign(incidentId, unitId, role) {
    performAction(
      () => apiRequest("POST", `/incidents/${incidentId}/assignments`, { unitId, role }),
      () => {
        setIncidents((prev) => prev.map((i) => (i.id === incidentId ? { ...i, assignedUnits: [...i.assignedUnits, { unitId, role }] } : i)));
        setUnits((prev) => prev.map((u) => (u.id === unitId ? { ...u, status: "assigned" } : u)));
      }
    );
  }
  // Where each unit is, for the map and for "nearest unit": a recent GPS fix if there is one, otherwise
  // inferred from its status and its call (on scene = at the pickup, at destination = at the drop-off...).
  const minute = Math.floor(now.getTime() / 60000);       // re-check "is the GPS still fresh" once a minute, not every second (the map redraws when this changes)
  // Long lists stay usable: available units first, then those on a call, then out of service; chips narrow either list.
  const unitGroup = (u) => (u.status === "available" ? "available" : u.status === "out_of_service" ? "out" : "oncall");
  const GROUP_RANK = { available: 0, oncall: 1, out: 2 };
  const unitCounts = { all: units.length, available: 0, oncall: 0, out: 0 };
  units.forEach((u) => { unitCounts[unitGroup(u)] += 1; });
  const unitsShown = units
    .filter((u) => unitFilter === "all" || unitGroup(u) === unitFilter)
    .sort((a, b) => (GROUP_RANK[unitGroup(a)] - GROUP_RANK[unitGroup(b)]) || a.designation.localeCompare(b.designation, undefined, { numeric: true }));
  const needsUnit = activeIncidents.filter((i) => i.assignedUnits.length === 0);
  const queueShown = queueFilter === "needs" ? needsUnit : queueFilter === "covered" ? activeIncidents.filter((i) => i.assignedUnits.length > 0) : activeIncidents;
  const placedUnits = useMemo(() => units.map((u) => {
    const call = incidents.find((i) => i.assignedUnits.some((a) => a.unitId === u.id));
    const pos = effectivePosition(u, call, minute * 60000);
    return pos ? { ...u, lat: pos.lat, lon: pos.lon, posEstimated: pos.estimated, posBasis: pos.basis } : { ...u, lat: null, lon: null };
  }), [units, incidents, minute]);
  const selIncident = incidents.find((i) => i.id === selIncidentId) || null;
  const selUnit = units.find((u) => u.id === selUnitId) || null;
  function toggleIncident(id) { setSelIncidentId((p) => (p === id ? null : id)); }
  function toggleUnit(id) { setSelUnitId((p) => (p === id ? null : id)); }
  function assignSelected() {
    if (!selIncident || !selUnit) return;
    const role = selIncident.assignedUnits.some((a) => a.role === "primary") ? "support" : "primary";
    handleAssign(selIncident.id, selUnit.id, role);
    setSelUnitId(null);
  }
  function handleRelease(incidentId, unitId) {
    performAction(
      () => apiRequest("DELETE", `/incidents/${incidentId}/assignments/${unitId}`),
      () => {
        setIncidents((prev) => prev.map((i) => (i.id === incidentId ? { ...i, assignedUnits: i.assignedUnits.filter((a) => a.unitId !== unitId) } : i)));
        setUnits((prev) => prev.map((u) => (u.id === unitId ? { ...u, status: "available" } : u)));
      }
    );
  }
  function handleComplete(incidentId) {
    performAction(
      () => apiRequest("POST", `/incidents/${incidentId}/complete`),
      () => {
        const incident = incidents.find((i) => i.id === incidentId);
        if (incident) {
          const unitIds = incident.assignedUnits.map((a) => a.unitId);
          setUnits((prev) => prev.map((u) => (unitIds.includes(u.id) ? { ...u, status: "available" } : u)));
        }
        setIncidents((prev) => prev.filter((i) => i.id !== incidentId));
      }
    );
  }
  // Calls are taken in the draft tray, not a pop-up, so the board stays usable while one is open.
  const openNewCall = () => openCallDraft({});
  const openEdit = (incident) => openCallDraft({ editingId: incident.id, form: formFromIncident(incident) });

  // Where to bias address search: wherever this agency's units already are.
  const searchNear = useMemo(() => {
    const o = units.find(hasFix) || incidents.find(hasFix);
    return o ? { lat: o.lat, lon: o.lon } : null;
  }, [units, incidents]);
  useEffect(() => { setCallNearHint(searchNear); }, [searchNear]);

  // The tray saves live calls itself and tells us to refresh; in the demo it hands the form to us.
  useEffect(() => {
    if (live) return;
    window.__emsDemoCalls = (f, editingId) => {
      if (editingId) {
        setIncidents((prev) => prev.map((i) => (i.id === editingId ? { ...i, type: f.type, priority: f.priority, capabilityNeeded: f.capabilityNeeded, address: f.address.trim(), detail: f.detail, destination: f.destination, patientName: f.patientName, contactName: f.contactName, contactPhone: f.contactPhone, notes: f.notes } : i)));
        return;
      }
      const lat = MAP_BOUNDS.latMin + Math.random() * (MAP_BOUNDS.latMax - MAP_BOUNDS.latMin);
      const lon = MAP_BOUNDS.lonMin + Math.random() * (MAP_BOUNDS.lonMax - MAP_BOUNDS.lonMin);
      setIncidents((prev) => [...prev, { id: `i${Date.now()}`, type: f.type, priority: f.priority, address: f.address.trim(), detail: f.detail, destination: f.destination, patientName: f.patientName, contactName: f.contactName, contactPhone: f.contactPhone, notes: f.notes, capabilityNeeded: f.capabilityNeeded, callReceivedAt: new Date(), assignedUnits: [], lat, lon }]);
    };
    return () => { delete window.__emsDemoCalls; };
  }, [live]);
  useEffect(() => {
    if (!live) return;
    const refresh = () => refreshFromApi().catch(() => {});
    window.addEventListener("ems-calls-changed", refresh);
    return () => window.removeEventListener("ems-calls-changed", refresh);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [live, apiRequest]);

  function handleCancelCall(incidentId, reason) {
    performAction(
      () => apiRequest("POST", `/incidents/${incidentId}/cancel`, { reason }),
      () => {
        const incident = incidents.find((i) => i.id === incidentId);
        if (incident) {
          const unitIds = incident.assignedUnits.map((a) => a.unitId);
          setUnits((prev) => prev.map((u) => (unitIds.includes(u.id) ? { ...u, status: "available" } : u)));
        }
        setIncidents((prev) => prev.filter((i) => i.id !== incidentId));
      }
    );
    if (selIncidentId === incidentId) setSelIncidentId(null);
  }
  function handleReset() {
    setUnits(makeInitialUnits());
    setIncidents(makeInitialIncidents(Date.now()));
  }

  if (!loaded) {
    return (
      <div style={{ backgroundColor: VOID, color: TEXT_SECONDARY }} className="min-h-screen w-full flex items-center justify-center text-sm">
        Loading console…
      </div>
    );
  }

  return (
    <div style={{ backgroundColor: VOID, color: TEXT_PRIMARY, fontFamily: "'Inter', system-ui, -apple-system, sans-serif" }} className="min-h-[calc(100vh_-_2.75rem)] w-full dispatch-root">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600&display=swap');
        .mono { font-family: 'JetBrains Mono', ui-monospace, monospace; }
        * { box-sizing: border-box; }
        select, button, input { font-family: inherit; }
        button:focus-visible, select:focus-visible, input:focus-visible { outline: 2px solid #4EA1F0; outline-offset: 1px; }
        .leaflet-popup-content-wrapper, .leaflet-popup-tip { background: #131A24; color: #E7ECF2; }
        .leaflet-container { background: #0D131B; }
        .map-dark .leaflet-tile-pane { filter: invert(1) hue-rotate(180deg) brightness(0.85) contrast(0.9); }
        .map-standard .leaflet-container { background: #E8E8E8; }
        .dispatch-root .text-xs { font-size: 13px; line-height: 1.4; }
        .dispatch-root .text-sm { font-size: 15px; }
        .ems-icon { background: none; border: none; }
        .ems-pin { position: absolute; display: flex; align-items: center; gap: 6px; white-space: nowrap; cursor: pointer; }
        .ems-unit { transform: translate(-8px, -50%); }
        .ems-inc { transform: translate(-11px, -50%); }
        .ems-pin .lbl { font: 600 12px/1 Inter, system-ui, sans-serif; color: #fff; background: rgba(10,14,19,0.92); border: 1.5px solid var(--c); padding: 4px 7px; border-radius: 6px; box-shadow: 0 1px 4px rgba(0,0,0,0.6); }
        .ems-pin .dot { width: 16px; height: 16px; border-radius: 50%; background: var(--c); border: 2px solid #fff; box-shadow: 0 0 0 2px rgba(0,0,0,0.5); }
        .ems-pin .ring { width: 22px; height: 22px; border-radius: 50%; border: 3px solid var(--c); background: rgba(0,0,0,0.35); box-shadow: 0 0 0 2px rgba(0,0,0,0.5); }
        .ems-pin.sel .dot, .ems-pin.sel .ring { box-shadow: 0 0 0 4px #fff, 0 0 14px 5px var(--c); transform: scale(1.25); }
        .ems-pin.dim { opacity: 0.6; }
        .ems-pin.est .dot { background: transparent; border: 2px dashed var(--c); box-shadow: none; }
        .ems-pin.est .lbl { border-style: dashed; }
        .ems-pd { transform: translate(-12px, -50%); }
        .ems-pd .pd { width: 24px; height: 24px; border-radius: 50%; background: rgba(10,14,19,0.92); border: 3px solid var(--c); color: #fff; font: 700 11px/1 Inter, system-ui, sans-serif; display: inline-flex; align-items: center; justify-content: center; box-shadow: 0 0 0 2px rgba(0,0,0,0.4); }
        .ems-pd .pdot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 5px; }
        .ems-pd.sel .pd { box-shadow: 0 0 0 4px #fff, 0 0 14px 5px var(--c); transform: scale(1.2); }
        .ems-pd.draft .pd { border-style: dashed; animation: emsPulse 1.2s ease-in-out infinite; }
        .ems-pd.dim { opacity: 0.35; }
        .ems-q { transform: translate(-6px, -50%); }
        .ems-q .pdq { width: 12px; height: 12px; border-radius: 50%; background: var(--c); color: #0A0E13; font: 700 7px/1 Inter, system-ui, sans-serif; display: inline-flex; align-items: center; justify-content: center; opacity: 0.8; }
        @keyframes emsPulse { 0%, 100% { box-shadow: 0 0 0 2px rgba(0,0,0,0.4); } 50% { box-shadow: 0 0 0 7px rgba(255,255,255,0.25); } }
      `}</style>

      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 px-4 py-3 border-b" style={{ borderColor: HAIRLINE }}>
        <div>
          <div className="text-xs tracking-widest uppercase" style={{ color: TEXT_FAINT }}>{live ? session.agency : "Ops Console · demo"}</div>
          <div className="text-lg font-semibold">Citywide Dispatch</div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="mono text-2xl">{now.toLocaleTimeString("en-US", { hour12: false })}</div>
          <div className="flex gap-2">
            <StatPill label="Available" value={`${availableCount}/${units.length}`} color="#34D399" />
            <StatPill label="Active" value={activeIncidents.length} color="#F5A623" />
          </div>
          <ConnectionBadge status={connectionStatus} />
          {!live && (
            <button onClick={handleReset} className="text-xs px-2 py-1 rounded" style={{ color: TEXT_FAINT, border: `1px solid ${HAIRLINE}` }}>
              Reset Demo
            </button>
          )}
        </div>
      </div>

      {actionError && (
        <div className="mx-4 mt-3 px-3 py-2 rounded-md text-xs flex items-center justify-between" style={{ backgroundColor: "rgba(240,85,74,0.1)", border: "1px solid #593434", color: RED }}>
          <span className="flex items-center gap-1.5"><AlertTriangle size={13} /> {actionError}</span>
          <button onClick={() => setActionError("")} style={{ color: RED }}><X size={14} /></button>
        </div>
      )}

      <div className="p-4 flex flex-col lg:grid lg:grid-cols-[minmax(0,1fr)_440px] gap-4 lg:items-start">
        <div className="flex flex-col gap-3 lg:sticky lg:top-3 min-w-0">
          <LiveMap
            units={placedUnits} incidents={activeIncidents}
            selUnitId={selUnitId} selIncidentId={selIncidentId}
            onSelectUnit={toggleUnit} onSelectIncident={toggleIncident}
          />
          <DispatchBar
            incident={selIncident} unit={selUnit}
            onAssign={assignSelected}
            onClear={() => { setSelIncidentId(null); setSelUnitId(null); }}
          />
        </div>
        {/* One screen tall on a desktop: each list scrolls inside its own panel, so the page does not grow with the number of calls and units. */}
        <div className="flex flex-col gap-3 min-w-0 lg:sticky lg:top-3 lg:h-[calc(100vh_-_9.5rem)] lg:min-h-[26rem]">
        <div className="rounded-lg border flex flex-col lg:flex-[3_1_0%] lg:min-h-0" style={{ backgroundColor: PANEL, borderColor: HAIRLINE }}>
          <div className="flex items-center justify-between gap-2 px-4 py-2.5 border-b shrink-0" style={{ borderColor: HAIRLINE }}>
            <div className="flex items-baseline gap-2 min-w-0">
              <div className="text-sm font-semibold tracking-wide">TRANSPORT QUEUE</div>
              <span className="mono text-xs" style={{ color: TEXT_FAINT }}>{activeIncidents.length}</span>
            </div>
            <button onClick={openNewCall} className="flex items-center gap-1 text-xs font-medium px-3 py-1.5 rounded-md" style={{ backgroundColor: SUNKEN, color: TEXT_PRIMARY, border: `1px solid ${HAIRLINE}` }}>
              <Plus size={14} /> New Call
            </button>
          </div>
          {(activeIncidents.length > 4 || queueFilter !== "all") && (
            <FilterChips label="Filter the transport queue" value={queueFilter} onChange={setQueueFilter} options={[
              { key: "all", label: "All", count: activeIncidents.length },
              { key: "needs", label: "Needs a unit", count: needsUnit.length },
              { key: "covered", label: "Has a unit", count: activeIncidents.length - needsUnit.length },
            ]} />
          )}
          <div className="overflow-y-auto max-h-[60vh] lg:max-h-none lg:flex-1 lg:min-h-0">
            {live && connectionStatus === "connecting" && (
              <div className="px-4 py-8 text-center text-sm" style={{ color: TEXT_FAINT }}>Loading your calls and units…</div>
            )}
            {activeIncidents.length === 0 && !(live && connectionStatus === "connecting") && (
              <div className="px-4 py-8 text-center text-sm" style={{ color: TEXT_FAINT }}>Queue clear. No active calls.</div>
            )}
            {queueShown.length === 0 && activeIncidents.length > 0 && (
              <div className="px-4 py-6 text-center text-sm" style={{ color: TEXT_FAINT }}>No calls match this filter.</div>
            )}
            {queueShown.map((incident) => (
              <IncidentRow key={incident.id} incident={incident} now={now} units={placedUnits} onAssign={handleAssign} onRelease={handleRelease} onComplete={handleComplete} onEdit={openEdit} onCancel={handleCancelCall} selected={incident.id === selIncidentId} onSelect={toggleIncident} />
            ))}
          </div>
        </div>

        <div className="rounded-lg border flex flex-col lg:flex-[2_1_0%] lg:min-h-0" style={{ backgroundColor: PANEL, borderColor: HAIRLINE }}>
          <div className="flex items-baseline gap-2 px-4 py-2.5 border-b shrink-0" style={{ borderColor: HAIRLINE }}>
            <div className="text-sm font-semibold tracking-wide">UNIT BOARD</div>
            <span className="mono text-xs" style={{ color: TEXT_FAINT }}>{units.length}</span>
          </div>
          {(units.length > 6 || unitFilter !== "all") && (
            <FilterChips label="Filter the unit board" value={unitFilter} onChange={setUnitFilter} options={[
              { key: "all", label: "All", count: unitCounts.all },
              { key: "available", label: "Available", count: unitCounts.available },
              { key: "oncall", label: "On a call", count: unitCounts.oncall },
              { key: "out", label: "Out of service", count: unitCounts.out },
            ]} />
          )}
          <div className="p-2 flex flex-col gap-1.5 overflow-y-auto max-h-[50vh] lg:max-h-none lg:flex-1 lg:min-h-0">
            {live && units.length === 0 && connectionStatus !== "connecting" && (
              <div className="px-1 py-4 text-sm" style={{ color: TEXT_FAINT }}>No units yet. A supervisor adds them under Team.</div>
            )}
            {unitsShown.length === 0 && units.length > 0 && (
              <div className="px-1 py-4 text-sm" style={{ color: TEXT_FAINT }}>No units match this filter.</div>
            )}
            {unitsShown.map((unit) => (
              <UnitCard key={unit.id} unit={unit} onStatusChange={handleStatusChange} selected={unit.id === selUnitId} onSelect={toggleUnit} />
            ))}
          </div>
        </div>
        </div>
      </div>

    </div>
  );
}

// One tap narrows a long list; the counts stay visible so nothing is hidden by surprise.
function FilterChips({ label, options, value, onChange }) {
  return (
    <div role="group" aria-label={label} className="flex gap-1.5 flex-wrap px-3 py-2 border-b shrink-0" style={{ borderColor: HAIRLINE }}>
      {options.map((o) => {
        const on = value === o.key;
        return (
          <button key={o.key} type="button" aria-pressed={on} onClick={() => onChange(o.key)} className="text-xs px-2 py-1 rounded-full"
            style={{ backgroundColor: on ? "rgba(78,161,240,0.15)" : SUNKEN, border: `1px solid ${on ? BLUE : HAIRLINE}`, color: on ? TEXT_PRIMARY : TEXT_SECONDARY }}>
            {o.label} <span className="mono" style={{ color: on ? BLUE : TEXT_FAINT }}>{o.count}</span>
          </button>
        );
      })}
    </div>
  );
}

function ConnectionBadge({ status }) {
  const cfg = {
    demo: { icon: WifiOff, color: TEXT_FAINT, label: "Demo Data" },
    connecting: { icon: Wifi, color: AMBER, label: "Connecting…" },
    live: { icon: Wifi, color: GREEN, label: "Live" },
    failed: { icon: WifiOff, color: RED, label: "Connection Failed" },
  }[status];
  const Icon = cfg.icon;
  return (
    <div className="flex items-center gap-1 text-xs px-2 py-1 rounded" style={{ color: cfg.color, border: `1px solid ${HAIRLINE}` }}>
      <Icon size={12} /> {cfg.label}
    </div>
  );
}

function StatPill({ label, value, color }) {
  return (
    <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md" style={{ backgroundColor: PANEL, border: `1px solid ${HAIRLINE}` }}>
      <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }}></span>
      <span className="text-xs" style={{ color: TEXT_SECONDARY }}>{label}</span>
      <span className="mono text-xs font-semibold">{value}</span>
    </div>
  );
}

// The live map. Colors carry the meaning:
//   units    colored by STATUS (available, en route, on scene...), dashed when the position is inferred
//   ongoing  a call with units on it: a cyan P (pickup) and a magenta D (drop-off), full size
//   queued   a call still waiting for a unit: small, dull grey-blue pins
//   a call you've selected shows its whole trip: P, D and the road route between them
//   a call being typed (not saved yet) shows as pulsing P?/D? pins
function LiveMap({ units, incidents, selUnitId, selIncidentId, onSelectUnit, onSelectIncident }) {
  const leafletStatus = useLeafletLoader();
  const [tilesWorking, setTilesWorking] = useState(null);
  const [trafficOn, setTrafficOn] = useState(true);
  const [draft, setDraft] = useState(null);                 // { pickup, dest } from the call form
  const [trip, setTrip] = useState(null);                   // road route for the selected call
  const [mapStyle, setMapStyle] = useState(() => {
    try { return localStorage.getItem("ems:mapstyle") === "dark" ? "dark" : "standard"; } catch (e) { return "standard"; }
  });
  const pickStyle = (v) => { setMapStyle(v); try { localStorage.setItem("ems:mapstyle", v); } catch (e) { /* not saved */ } };
  const containerRef = useRef(null);
  const mapRef = useRef(null);
  const layerRef = useRef(null);
  const trafficRef = useRef(null);
  const fittedRef = useRef({ first: false, sel: null, draft: "" });
  const tileStatsRef = useRef({ errors: 0, loads: 0 });
  const cbRef = useRef({});
  cbRef.current = { unit: onSelectUnit, incident: onSelectIncident };

  const selected = incidents.find((i) => i.id === selIncidentId) || null;
  const pin = (o) => (hasFix(o) ? { lat: o.lat, lon: o.lon } : null);
  const dropPin = (o) => (o && o.destLat != null && o.destLon != null ? { lat: o.destLat, lon: o.destLon } : null);

  useEffect(() => {
    const on = (e) => setDraft(e.detail && (e.detail.pickup || e.detail.dest) ? e.detail : null);
    window.addEventListener("ems-draft-preview", on);
    return () => window.removeEventListener("ems-draft-preview", on);
  }, []);

  // the road route for whichever call is selected
  useEffect(() => {
    const a = pin(selected), b = dropPin(selected);
    if (!a || !b) { setTrip(null); return; }
    let cancelled = false;
    fetchRoute(a, b).then((r) => { if (!cancelled) setTrip(r); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected?.id, selected?.lat, selected?.lon, selected?.destLat, selected?.destLon]);

  useEffect(() => {
    if (leafletStatus !== "ready" || !containerRef.current || mapRef.current) return;
    const L = window.L;
    const map = L.map(containerRef.current).setView([40.85, -73.89], 12);
    const tileLayer = L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { attribution: "&copy; OpenStreetMap contributors", maxZoom: 19 });
    tileLayer.on("tileload", () => { tileStatsRef.current.loads++; setTilesWorking((prev) => (prev === null ? true : prev)); });
    tileLayer.on("tileerror", () => {
      tileStatsRef.current.errors++;
      if (tileStatsRef.current.errors >= 4 && tileStatsRef.current.loads === 0 && mapRef.current) { mapRef.current.remove(); mapRef.current = null; setTilesWorking(false); }
    });
    tileLayer.addTo(map);
    if (TOMTOM_KEY) {
      map.createPane("traffic");
      map.getPane("traffic").style.zIndex = 250;
      trafficRef.current = L.tileLayer(`https://api.tomtom.com/traffic/map/4/tile/flow/relative0/{z}/{x}/{y}.png?key=${TOMTOM_KEY}`, { pane: "traffic", maxZoom: 19, opacity: 0.9 });
    }
    layerRef.current = L.layerGroup().addTo(map);
    mapRef.current = map;
    return () => { if (mapRef.current) { mapRef.current.remove(); mapRef.current = null; } };
  }, [leafletStatus]);

  useEffect(() => {
    const map = mapRef.current, t = trafficRef.current;
    if (!map || !t) return;
    if (trafficOn) t.addTo(map); else map.removeLayer(t);
  }, [trafficOn, tilesWorking]);

  function fitTo(points, maxZoom = 15) {
    const map = mapRef.current;
    if (map && points.length > 0) map.fitBounds(points, { padding: [70, 70], maxZoom });
  }
  function fitAll() {
    fitTo([...units.filter(hasFix).map((u) => [u.lat, u.lon]), ...incidents.flatMap((i) => [pin(i), dropPin(i)].filter(Boolean).map((p) => [p.lat, p.lon]))], 14);
  }

  useEffect(() => {
    if (!mapRef.current || !layerRef.current) return;
    const L = window.L;
    const g = layerRef.current;
    g.clearLayers();
    const mk = (latlng, html, opts = {}) => L.marker(latlng, { icon: L.divIcon({ className: "ems-icon", iconSize: [0, 0], html }), ...opts }).addTo(g);
    const short = (t, n = 30) => (String(t).length > n ? String(t).slice(0, n - 1) + "\u2026" : String(t));

    // ---- calls
    incidents.forEach((i) => {
      const isSel = i.id === selIncidentId;
      const ongoing = i.assignedUnits.length > 0;
      const p = pin(i), d = dropPin(i);
      if (selected && !isSel && !ongoing) return;            // with a call selected, other waiting calls get out of the way
      const dim = selected && !isSel;                        // ...and other ongoing calls fade
      const prio = PRIORITY_CONFIG[i.priority].color;
      const click = () => cbRef.current.incident && cbRef.current.incident(i.id);
      if (p && d && !isSel) L.polyline([[p.lat, p.lon], [d.lat, d.lon]], { color: ongoing ? DROPOFF_COLOR : QUEUED_COLOR, weight: 1.5, dashArray: "3 6", opacity: dim ? 0.25 : ongoing ? 0.7 : 0.5 }).addTo(g);
      if (ongoing || isSel) {
        if (p) mk([p.lat, p.lon], `<div class="ems-pin ems-pd${isSel ? " sel" : ""}${dim ? " dim" : ""}" style="--c:${PICKUP_COLOR}"><span class="pd">P</span><span class="lbl"><i class="pdot" style="background:${prio}"></i>${escMap(short(i.address))}</span></div>`, { zIndexOffset: isSel ? 900 : 100 }).on("click", click);
        if (d) mk([d.lat, d.lon], `<div class="ems-pin ems-pd${isSel ? " sel" : ""}${dim ? " dim" : ""}" style="--c:${DROPOFF_COLOR}"><span class="pd">D</span><span class="lbl">${escMap(short(i.destination || "Drop-off"))}</span></div>`, { zIndexOffset: isSel ? 900 : 100 }).on("click", click);
      } else {
        const tip = `${i.address}${i.destination ? " \u2192 " + i.destination : ""} (waiting for a unit)`;
        if (p) mk([p.lat, p.lon], `<div class="ems-pin ems-q" style="--c:${QUEUED_COLOR}"><span class="pdq">P</span></div>`, { title: tip }).on("click", click);
        if (d) mk([d.lat, d.lon], `<div class="ems-pin ems-q" style="--c:${QUEUED_COLOR}"><span class="pdq">D</span></div>`, { title: tip }).on("click", click);
      }
      if (isSel && p && d) {
        if (trip) L.polyline(trip.points, { color: BLUE, weight: 5, opacity: 0.85 }).addTo(g);
        else L.polyline([[p.lat, p.lon], [d.lat, d.lon]], { color: BLUE, weight: 3, dashArray: "8 8", opacity: 0.8 }).addTo(g);
      }
    });

    // ---- a call that is still being typed
    if (draft) {
      const dp = draft.pickup, dd = draft.dest;
      if (dp && dd) L.polyline([[dp.lat, dp.lon], [dd.lat, dd.lon]], { color: "#FFFFFF", weight: 2, dashArray: "4 6", opacity: 0.8 }).addTo(g);
      if (dp) mk([dp.lat, dp.lon], `<div class="ems-pin ems-pd draft" style="--c:${PICKUP_COLOR}"><span class="pd">P?</span><span class="lbl">${escMap(short(dp.label || "Pickup (not saved)"))}</span></div>`, { zIndexOffset: 1200 });
      if (dd) mk([dd.lat, dd.lon], `<div class="ems-pin ems-pd draft" style="--c:${DROPOFF_COLOR}"><span class="pd">D?</span><span class="lbl">${escMap(short(dd.label || "Drop-off (not saved)"))}</span></div>`, { zIndexOffset: 1200 });
    }

    // ---- units, by status; dashed when the place is inferred rather than a GPS fix
    units.filter(hasFix).forEach((u) => {
      const color = STATUS_CONFIG[u.status].color;
      const dim = selected && !selected.assignedUnits.some((a) => a.unitId === u.id) && u.id !== selUnitId;
      mk([u.lat, u.lon], `<div class="ems-pin ems-unit${u.id === selUnitId ? " sel" : ""}${u.posEstimated ? " est" : ""}${dim ? " dim" : ""}" style="--c:${color}"><span class="dot"></span><span class="lbl">${escMap(u.designation)} \u00b7 ${escMap(u.capability)} \u00b7 ${escMap(STATUS_CONFIG[u.status].label)}</span></div>`,
        { zIndexOffset: u.id === selUnitId ? 1000 : 500, title: u.posBasis ? `${u.designation}: ${u.posBasis}` : u.designation }).on("click", () => cbRef.current.unit && cbRef.current.unit(u.id));
    });

    // ---- where to look
    const f = fittedRef.current;
    const draftKey = draft ? `${draft.pickup?.lat},${draft.pickup?.lon};${draft.dest?.lat},${draft.dest?.lon}` : "";
    if (draftKey && draftKey !== f.draft) {
      f.draft = draftKey;
      fitTo([draft.pickup, draft.dest].filter(Boolean).map((x) => [x.lat, x.lon]), 15);
    } else if (!draftKey) f.draft = "";
    if ((selIncidentId || null) !== f.sel) {
      f.sel = selIncidentId || null;
      if (selected) {
        const pts = [pin(selected), dropPin(selected), ...units.filter((u) => selected.assignedUnits.some((a) => a.unitId === u.id) && hasFix(u))].filter(Boolean).map((x) => [x.lat, x.lon]);
        fitTo(pts, 15);
      }
    }
    if (!f.first && (units.some(hasFix) || incidents.some(hasFix))) { fitAll(); f.first = true; }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [units, incidents, selUnitId, selIncidentId, tilesWorking, draft, trip]);

  // keep the trip in view once its road route arrives
  useEffect(() => { if (trip && selected) fitTo(trip.points, 15); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [trip]);

  if (leafletStatus === "failed" || tilesWorking === false) {
    return <ZoneMap units={units} incidents={incidents} />;
  }
  const chip = { backgroundColor: SUNKEN, border: `1px solid ${HAIRLINE}`, color: TEXT_PRIMARY };
  const noPin = selected && !hasFix(selected);
  return (
    <div className="rounded-lg border p-3" style={{ backgroundColor: PANEL, borderColor: HAIRLINE }}>
      <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
        <div className="text-xs tracking-wide font-semibold" style={{ color: TEXT_SECONDARY }}>
          {selected ? `TRIP: ${selected.address}${selected.destination ? ` \u2192 ${selected.destination}` : ""}` : "LIVE MAP: ongoing calls and unit locations. Tap a call or unit to select it."}
        </div>
        <div className="flex items-center gap-2 text-xs">
          {selected && <button onClick={() => onSelectIncident(selected.id)} className="px-2.5 py-1.5 rounded-md" style={chip}>Clear selection</button>}
          <div className="flex rounded-md overflow-hidden" style={{ border: `1px solid ${HAIRLINE}` }}>
            {[["standard", "Standard"], ["dark", "Dark"]].map(([key, label]) => (
              <button key={key} onClick={() => pickStyle(key)} className="px-2.5 py-1.5" style={{ backgroundColor: mapStyle === key ? BLUE : SUNKEN, color: mapStyle === key ? "#06090D" : TEXT_PRIMARY, fontWeight: mapStyle === key ? 600 : 400 }}>{label}</button>
            ))}
          </div>
          <button onClick={fitAll} className="px-2.5 py-1.5 rounded-md" style={chip}>Fit all</button>
          {TOMTOM_KEY ? (
            <button onClick={() => setTrafficOn((v) => !v)} className="px-2.5 py-1.5 rounded-md" style={{ ...chip, borderColor: trafficOn ? GREEN : HAIRLINE, color: trafficOn ? GREEN : TEXT_PRIMARY }}>Traffic {trafficOn ? "on" : "off"}</button>
          ) : (
            <span style={{ color: TEXT_FAINT }} title="Set VITE_TOMTOM_KEY in Vercel to enable the traffic layer">Traffic: not configured</span>
          )}
          <span style={{ color: tilesWorking === true ? GREEN : TEXT_FAINT }}>{tilesWorking === true ? "Map live" : "Loading map…"}</span>
        </div>
      </div>
      {selected && (trip || noPin) && (
        <div className="text-xs mb-2" style={{ color: noPin ? AMBER : TEXT_SECONDARY }}>
          {noPin ? "This call has no pin on the map yet. Edit it and use Find to place the pickup." : `Pickup to drop-off: ${trip.miles.toFixed(1)} mi, about ${Math.round(trip.minutes)} min by road (no live traffic).`}
        </div>
      )}
      <div className={"relative " + (mapStyle === "dark" ? "map-dark" : "map-standard")}>
        <div ref={containerRef} style={{ height: "clamp(340px, calc(100vh - 330px), 900px)", borderRadius: "6px", backgroundColor: SUNKEN }} />
        <MapLegend />
      </div>
    </div>
  );
}

function MapLegend() {
  const [open, setOpen] = useState(false);
  const row = (swatch, text) => <div className="flex items-center gap-2">{swatch}<span>{text}</span></div>;
  const dot = (c, dashed) => <span style={{ width: 12, height: 12, borderRadius: "50%", backgroundColor: dashed ? "transparent" : c, border: `2px ${dashed ? "dashed" : "solid"} ${c}`, display: "inline-block" }} />;
  const pd = (c, t, small) => <span style={{ width: small ? 11 : 16, height: small ? 11 : 16, borderRadius: "50%", backgroundColor: small ? c : "rgba(10,14,19,.9)", border: `2px solid ${c}`, color: "#fff", fontSize: small ? 7 : 9, fontWeight: 700, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>{t}</span>;
  return (
    <div className="absolute" style={{ left: 8, bottom: 8, zIndex: 500, pointerEvents: "auto" }}>
      {open ? (
        <div className="rounded-md text-xs flex flex-col gap-1 p-2" style={{ backgroundColor: "rgba(10,14,19,0.92)", border: `1px solid ${HAIRLINE}`, color: TEXT_PRIMARY, maxWidth: 230 }}>
          <div className="flex items-center justify-between"><b>Map key</b><button onClick={() => setOpen(false)} style={{ color: TEXT_FAINT }}>Hide</button></div>
          {Object.entries(STATUS_CONFIG).map(([k, v]) => <div key={k}>{row(dot(v.color), v.label)}</div>)}
          {row(dot("#9CA3AF", true), "Dashed: position estimated from status (no GPS yet)")}
          {row(pd(PICKUP_COLOR, "P"), "Pickup of an ongoing call")}
          {row(pd(DROPOFF_COLOR, "D"), "Drop-off of an ongoing call")}
          {row(pd(QUEUED_COLOR, "P", true), "Small and dull: call waiting for a unit")}
          {row(pd("#FFFFFF", "?"), "Pulsing: a call being typed, not saved")}
        </div>
      ) : <button onClick={() => setOpen(true)} className="rounded-md text-xs px-2 py-1.5" style={{ backgroundColor: "rgba(10,14,19,0.92)", border: `1px solid ${HAIRLINE}`, color: TEXT_PRIMARY }}>Map key</button>}
    </div>
  );
}

function DispatchBar({ incident, unit, onAssign, onClear }) {
  if (!incident && !unit) {
    return (
      <div className="rounded-lg border px-4 py-3 text-sm" style={{ backgroundColor: PANEL, borderColor: HAIRLINE, color: TEXT_SECONDARY }}>
        Select a call and a unit (on the map or in the lists) to dispatch.
      </div>
    );
  }
  const located = (o) => o && o.lat != null && o.lon != null;
  const miles = located(incident) && located(unit) ? haversineMiles(unit, incident) : null;
  const eta = miles != null ? Math.max(1, Math.round(estimateEtaMinutes(miles))) : null;
  const needsAls = incident && incident.capabilityNeeded === "ALS" && unit && unit.capability === "BLS";
  const unitFree = unit && unit.status === "available";
  const canAssign = incident && unit && unitFree;
  let hint = "";
  if (incident && unit && !unitFree) hint = `${unit.designation} is ${STATUS_CONFIG[unit.status].label.toLowerCase()} \u2014 free it first.`;
  else if (needsAls) hint = "This call needs ALS; this unit is BLS.";
  else if (incident && !unit) hint = "Now pick a unit.";
  else if (unit && !incident) hint = "Now pick a call.";
  return (
    <div className="rounded-lg border px-4 py-3 flex flex-col gap-2" style={{ backgroundColor: PANEL, borderColor: HAIRLINE }}>
      <div className="flex flex-wrap items-center gap-x-6 gap-y-1 text-sm">
        <div>
          <span style={{ color: TEXT_FAINT }}>Call: </span>
          {incident ? <span className="font-semibold">{incident.address} <span style={{ color: PRIORITY_CONFIG[incident.priority].color }}>({PRIORITY_CONFIG[incident.priority].label}, {incident.capabilityNeeded})</span></span> : <span style={{ color: TEXT_FAINT }}>none</span>}
        </div>
        <div>
          <span style={{ color: TEXT_FAINT }}>Unit: </span>
          {unit ? <span className="font-semibold mono">{unit.designation} <span style={{ color: STATUS_CONFIG[unit.status].color }}>({unit.capability}, {STATUS_CONFIG[unit.status].label})</span></span> : <span style={{ color: TEXT_FAINT }}>none</span>}
        </div>
        {eta != null && <div style={{ color: TEXT_SECONDARY }}>{miles.toFixed(1)} mi straight-line \u00b7 ~{eta} min (estimate, no live traffic)</div>}
      </div>
      <div className="flex items-center gap-3 flex-wrap">
        <button onClick={onAssign} disabled={!canAssign} className="px-4 rounded-md text-sm font-semibold" style={{ minHeight: "44px", backgroundColor: canAssign ? "#1F6B4A" : SUNKEN, color: canAssign ? "#fff" : TEXT_FAINT, border: `1px solid ${canAssign ? GREEN : HAIRLINE}`, cursor: canAssign ? "pointer" : "not-allowed" }}>
          {unit && incident ? `Assign ${unit.designation} to this call` : "Assign"}
        </button>
        <button onClick={onClear} className="px-4 rounded-md text-sm" style={{ minHeight: "44px", backgroundColor: SUNKEN, border: `1px solid ${HAIRLINE}`, color: TEXT_PRIMARY }}>Clear</button>
        {hint && <span className="text-xs" style={{ color: needsAls || (unit && !unitFree) ? AMBER : TEXT_SECONDARY }}>{hint}</span>}
      </div>
    </div>
  );
}

function ZoneMap({ units, incidents }) {
  const gridLines = [20, 40, 60, 80];
  return (
    <div className="rounded-lg border p-3" style={{ backgroundColor: PANEL, borderColor: HAIRLINE }}>
      <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
        <div className="text-xs tracking-wide" style={{ color: TEXT_FAINT }}>SERVICE AREA — BRONX, NY</div>
        <div className="text-xs" style={{ color: "#55627A" }}>Schematic fallback — real map tiles unavailable</div>
      </div>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full" style={{ height: "140px", backgroundColor: SUNKEN, borderRadius: "6px" }}>
        {gridLines.map((v) => <line key={`v${v}`} x1={v} y1="0" x2={v} y2="100" stroke="#1B2330" strokeWidth="0.3" />)}
        {gridLines.map((v) => <line key={`h${v}`} x1="0" y1={v} x2="100" y2={v} stroke="#1B2330" strokeWidth="0.3" />)}
        {incidents.filter((i) => i.assignedUnits.length === 0 && i.lat != null).map((i) => {
          const p = project(i.lat, i.lon);
          return <circle key={i.id} cx={p.x} cy={p.y} r="2.2" fill="none" stroke={PRIORITY_CONFIG[i.priority].color} strokeWidth="0.8" />;
        })}
        {units.filter((u) => u.lat != null).map((u) => {
          const p = project(u.lat, u.lon);
          return <circle key={u.id} cx={p.x} cy={p.y} r="1.6" fill={STATUS_CONFIG[u.status].color} />;
        })}
      </svg>
    </div>
  );
}

function EtaText({ miles, etaMin, routed, status }) {
  if (miles == null) return <span className="text-xs mono" style={{ color: TEXT_FAINT }}>no GPS fix, distance unknown</span>;
  if (status === "live" && routed) {
    return <span className="text-xs mono" style={{ color: TEXT_SECONDARY }}>~{Math.round(routed.etaMin)} min · {routed.miles.toFixed(1)} mi <span style={{ color: BLUE }} title="Road route; does not account for live traffic">· by road</span></span>;
  }
  return <span className="text-xs mono" style={{ color: TEXT_SECONDARY }}>~{Math.round(etaMin)} min · {miles.toFixed(1)} mi <span style={{ color: TEXT_FAINT }}>{status === "loading" ? "· checking road route…" : "· straight-line estimate"}</span></span>;
}

function IncidentRow({ incident, now, units, onAssign, onRelease, onComplete, onEdit, onCancel, selected, onSelect }) {
  const [more, setMore] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [reason, setReason] = useState("");
  const rowRef = useRef(null);
  // The lists scroll inside their panels now, so a call picked on the map is brought into view.
  useEffect(() => { if (selected) rowRef.current?.scrollIntoView?.({ block: "nearest" }); }, [selected]);
  const elapsedMs = now - incident.callReceivedAt;
  const target = PRIORITY_CONFIG[incident.priority].targetMin * 60 * 1000;
  const ratio = elapsedMs / target;
  const timerColor = ratio > 1 ? "#F0554A" : ratio > 0.7 ? "#F5A623" : TEXT_SECONDARY;
  const assignedUnits = incident.assignedUnits.map((a) => ({ ...a, unit: units.find((u) => u.id === a.unitId) })).filter((a) => a.unit);
  const rec = getRecommendation(incident, units);
  const { routed, status: routeStatus } = useRoutedEta(rec?.best?.unit, incident);
  const stop = (fn) => (e) => { e.stopPropagation(); fn(); };
  const small = { backgroundColor: SUNKEN, border: `1px solid ${HAIRLINE}`, color: TEXT_SECONDARY };
  const expanded = more || selected || confirming || cancelling;
  const hasMore = Boolean(incident.destination || incident.patientName || incident.contactName || incident.contactPhone || incident.notes);
  const noCrewAtAll = units.length > 0 && units.every((u) => u.crew.length === 0);
  // A call already covered at the level it needs doesn't need a second suggestion on every row: it shows when the
  // call is opened, or whenever the call still lacks the level it needs (an ALS call with only a BLS unit, say).
  const CAP_RANK = { BLS: 1, ALS: 2, CCT: 3 };
  const covered = assignedUnits.length > 0 && assignedUnits.some((a) => (CAP_RANK[a.unit.capability] || 0) >= (CAP_RANK[incident.capabilityNeeded] || 0));
  const showRec = !covered || expanded;

  return (
    <div ref={rowRef} className="px-4 py-2.5 border-b" onClick={() => onSelect && onSelect(incident.id)} style={{ borderColor: "#1B2330", cursor: "pointer", backgroundColor: selected ? "rgba(78,161,240,0.10)" : undefined, boxShadow: selected ? `inset 4px 0 0 ${BLUE}` : undefined }}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-semibold px-1.5 py-0.5 rounded" style={{ color: PRIORITY_CONFIG[incident.priority].color, backgroundColor: "rgba(255,255,255,0.04)" }}>
              {PRIORITY_CONFIG[incident.priority].label.toUpperCase()}
            </span>
            <span className="text-xs" style={{ color: TEXT_FAINT }}>{TYPE_LABELS[incident.type] || incident.type}</span>
            <span className="text-xs px-1.5 py-0.5 rounded" style={{ color: TEXT_SECONDARY, backgroundColor: SUNKEN }}>{incident.capabilityNeeded}</span>
            {incident.lat == null && <span className="text-xs px-1.5 py-0.5 rounded" style={{ color: AMBER, backgroundColor: "rgba(245,147,74,0.1)" }} title="Edit the call and use Find to pin it on the map">no map pin</span>}
          </div>
          <div className="text-sm mt-1">{incident.address}{incident.detail ? <span style={{ color: TEXT_SECONDARY }}> · {incident.detail}</span> : null}</div>
          {incident.destination && <div className="text-sm" style={{ color: TEXT_SECONDARY }}>→ {incident.destination}</div>}
          {expanded && (incident.patientName || incident.contactName || incident.contactPhone) && (
            <div className="text-xs mt-0.5" style={{ color: TEXT_FAINT }}>
              {incident.patientName && <>Patient: {incident.patientName}</>}
              {incident.patientName && (incident.contactName || incident.contactPhone) && " · "}
              {(incident.contactName || incident.contactPhone) && <>Contact: {[incident.contactName, incident.contactPhone].filter(Boolean).join(" ")}</>}
            </div>
          )}
          {expanded && incident.notes && <div className="text-xs mt-0.5" style={{ color: TEXT_FAINT }}>Note: {incident.notes}</div>}
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <div className="mono text-sm" style={{ color: timerColor }}>{formatElapsed(elapsedMs)}</div>
          <button onClick={(e) => { e.stopPropagation(); setMore(!more); }} aria-expanded={expanded} aria-label={expanded ? "Show less" : "Show details"} className="text-xs px-1.5 py-0.5 rounded" style={small}>{expanded ? "▲" : "▼"}</button>
        </div>
      </div>

      {assignedUnits.length > 0 && (
        <div className="mt-2 flex flex-col gap-1">
          {assignedUnits.map((a) => (
            <div key={a.unitId} className="flex items-center gap-2 flex-wrap text-xs">
              <span style={{ color: TEXT_SECONDARY }}>Assigned ({ROLE_LABELS[a.role] || a.role}):</span>
              <span className="font-medium mono">{a.unit.designation}</span>
              <button onClick={stop(() => onRelease(incident.id, a.unitId))} className="px-1.5 py-0.5 rounded" style={small}>Release</button>
            </div>
          ))}
        </div>
      )}

      {showRec && (
      <div className="mt-2 flex flex-col gap-1">
        {rec?.best ? (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs" style={{ color: TEXT_SECONDARY }}>{assignedUnits.length === 0 ? "Nearest available:" : "Nearest additional unit:"}</span>
            <span className="text-xs font-medium mono">{rec.best.unit.designation} <span style={{ color: TEXT_FAINT }}>({rec.best.unit.capability})</span></span>
            <EtaText miles={rec.best.miles} etaMin={rec.best.etaMin} routed={routed} status={routeStatus} />
            {rec.isMismatch && <span className="text-xs flex items-center gap-1" style={{ color: AMBER }}><AlertTriangle size={12} /> not {incident.capabilityNeeded}, consider an intercept</span>}
            <button onClick={stop(() => onAssign(incident.id, rec.best.unit.id, rec.role))} className="text-xs px-2 py-1 rounded font-medium" style={{ backgroundColor: "#1E3A2E", border: "1px solid #2E5943", color: GREEN }}>
              Assign {rec.best.unit.designation}
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-1 text-xs" style={{ color: rec?.soon ? TEXT_SECONDARY : RED }}>
            <AlertTriangle size={12} />
            {noCrewAtAll ? "No unit has a crew yet. Put people on units under Team." : rec?.soon ? "No unit is free right now." : "No unit available. Mutual aid may be needed."}
          </div>
        )}
        {rec?.soon && (
          <div className="flex items-center gap-2 flex-wrap text-xs" style={{ color: TEXT_SECONDARY }}>
            <span>{rec.best ? "Closer, but finishing a call:" : "Soonest to clear:"}</span>
            <span className="font-medium mono">{rec.soon.unit.designation}</span>
            <span style={{ color: TEXT_FAINT }}>(at destination)</span>
            <EtaText miles={rec.soon.miles} etaMin={rec.soon.etaMin} routed={null} status="fallback" />
          </div>
        )}
      </div>
      )}

      {expanded && <div className="mt-2 flex items-center gap-2 flex-wrap" onClick={(e) => e.stopPropagation()}>
        {assignedUnits.length > 0 && !cancelling && (confirming ? (
          <>
            <button onClick={() => onComplete(incident.id)} className="text-xs px-2 py-1 rounded font-medium" style={{ backgroundColor: "#3A1E1E", border: "1px solid #593434", color: "#F0857D" }}>Confirm complete</button>
            <button onClick={() => setConfirming(false)} className="text-xs px-2 py-1 rounded" style={small}>Back</button>
          </>
        ) : (
          <button onClick={() => setConfirming(true)} className="text-xs px-2 py-1 rounded" style={small}>Complete (release all)</button>
        ))}
        {!confirming && !cancelling && <button onClick={() => onEdit(incident)} className="text-xs px-2 py-1 rounded" style={small}>Edit</button>}
        {!confirming && !cancelling && <button onClick={() => setCancelling(true)} className="text-xs px-2 py-1 rounded" style={{ ...small, color: "#F0857D" }}>Cancel call</button>}
        {cancelling && (
          <div className="flex items-center gap-2 flex-wrap w-full">
            <input autoFocus value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Why is it being cancelled?" className="text-xs rounded px-2 py-1.5 flex-1" style={{ minWidth: "160px", backgroundColor: SUNKEN, border: `1px solid ${HAIRLINE}`, color: TEXT_PRIMARY }} />
            <button disabled={reason.trim().length < 3} onClick={() => onCancel(incident.id, reason.trim())} className="text-xs px-2 py-1.5 rounded font-medium" style={{ backgroundColor: "#3A1E1E", border: "1px solid #593434", color: reason.trim().length < 3 ? TEXT_FAINT : "#F0857D" }}>Confirm cancel</button>
            <button onClick={() => { setCancelling(false); setReason(""); }} className="text-xs px-2 py-1.5 rounded" style={small}>Keep call</button>
          </div>
        )}
      </div>}
    </div>
  );
}

function UnitCard({ unit, onStatusChange, selected, onSelect }) {
  const cfg = STATUS_CONFIG[unit.status];
  const Icon = cfg.icon;
  const rowRef = useRef(null);
  // The lists scroll inside their panels now, so a unit picked on the map is brought into view.
  useEffect(() => { if (selected) rowRef.current?.scrollIntoView?.({ block: "nearest" }); }, [selected]);
  const crewName = (c) => (c.employeeId ? `${c.employeeId} - ${c.name}` : c.name);   // "employee id - full name", or just the name when there is no number
  const crewLine = (c) => `${crewName(c)} \u2014 ${CREW_LABELS[c.role] || c.role}${c.cert ? ` ${c.cert}` : ""}`;
  return (
    <div ref={rowRef} className="rounded-md px-3 py-1.5" onClick={() => onSelect && onSelect(unit.id)} style={{ backgroundColor: SUNKEN, border: `1px solid ${selected ? BLUE : HAIRLINE}`, cursor: "pointer", boxShadow: selected ? `0 0 0 1px ${BLUE}` : undefined }}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <Icon size={16} color={cfg.color} className="shrink-0" />
          <div className="min-w-0 flex-1 flex flex-col sm:flex-row sm:items-baseline sm:gap-2">
            <div className="flex items-center gap-1.5 shrink-0">
              <span className="mono text-sm font-medium">{unit.designation}</span>
              <span className="text-xs px-1 rounded" style={{ color: TEXT_SECONDARY, backgroundColor: PANEL }}>{unit.capability}</span>
              {unit.vehicleNumber && <span className="text-xs" style={{ color: TEXT_FAINT }}>veh {unit.vehicleNumber}</span>}
              {unit.vehicleNumber === null && unit.crew.length > 0 && <span className="text-xs" style={{ color: AMBER }}>no vehicle</span>}
            </div>
            {!selected && (unit.crew.length === 0
              ? <span className="text-xs" style={{ color: TEXT_FAINT }}>No crew</span>
              : <span className="text-xs truncate min-w-0" style={{ color: TEXT_FAINT }} title={unit.crew.map(crewLine).join("\n")}>{unit.crew.map(crewName).join(" \u00b7 ")}</span>)}
          </div>
        </div>
        <select value={unit.status} onChange={(e) => onStatusChange(unit.id, e.target.value)} className="text-xs rounded px-1.5 py-1 shrink-0" style={{ backgroundColor: PANEL, color: cfg.color, border: `1px solid ${HAIRLINE}` }}>
          {Object.entries(STATUS_CONFIG).map(([key, c]) => <option key={key} value={key} style={{ color: "#000" }}>{c.label}</option>)}
        </select>
      </div>
      {selected && (
        <div className="mt-1 pl-6 flex flex-col">
          {unit.crew.length === 0
            ? <span className="text-xs" style={{ color: TEXT_FAINT }}>No crew \u2014 out of service</span>
            : unit.crew.map((c, i) => <span key={i} className="text-xs mono truncate" style={{ color: TEXT_FAINT }}>{crewLine(c)}</span>)}
        </div>
      )}
    </div>
  );
}
