// backend_auth.js
// -----------------------------------------------------------------------
// Turns a bearer token into a user — and decides whether that user may
// act. This deliberately does NOT implement OIDC/SAML itself: that
// belongs to a real identity provider (Azure AD/Entra ID, Okta, etc.) or
// a battle-tested library, not a hand-rolled auth flow.
//
// The division of labor matters. The token only proves WHO is asking.
// The database decides what they may do and whether they may do
// anything at all: role, whether the user is active, whether their
// agency is active. This used to verify the signature and then trust
// every claim in the token, so a terminated employee, a downgraded
// role, or a suspended agency kept working until the token happened to
// expire. Looking it up on every request is what makes revocation
// immediate; it costs a query per request, and caching it would give
// back exactly the delay this exists to remove.
//
// It assumes the token's `sub` IS the user's UUID in the users table.
// Real identity providers often use opaque subject strings instead;
// mapping users.external_idp_subject to users.user_id belongs here
// when one is connected.
// -----------------------------------------------------------------------

import jwt from "jsonwebtoken";
import crypto from "crypto";
import { requestContext } from "./backend_context.js";
import { withTenant } from "./backend_db.js";
import { auditDenied } from "./backend_audit.js";

// The public key arrives through an environment variable, and phones, dashboards
// and copy-paste mangle it in many ways: real newlines, literal "\\n", wrapping
// quotes, a missing BEGIN/END header. Accept all of them.
export function normalizeKey(raw) {
  let k = (raw || "").trim().replace(/^["']|["']$/g, "").replace(/\\n/g, "\n").trim();
  if (k && !k.includes("BEGIN")) {
    const body = k.replace(/\s+/g, "");
    k = `-----BEGIN PUBLIC KEY-----\n${(body.match(/.{1,64}/g) || []).join("\n")}\n-----END PUBLIC KEY-----`;
  }
  return k;
}

// For /api/health: says whether the key can be read, never what it is.
export function publicKeyStatus() {
  if (!process.env.JWT_PUBLIC_KEY) return "missing";
  try { crypto.createPublicKey(normalizeKey(process.env.JWT_PUBLIC_KEY)); return "valid"; } catch (e) { return "unreadable"; }
}

// Sessions issued by the app's own sign-in are signed with SESSION_SECRET
// (a long random string only the server knows). Tokens signed with the older
// RSA key pair still verify while JWT_PUBLIC_KEY is set; remove that
// variable to turn them off.
function sessionSecret() {
  const s = process.env.SESSION_SECRET || "";
  return s.length >= 32 ? s : null;
}
export function sessionSecretStatus() {
  if (!process.env.SESSION_SECRET) return "missing";
  return process.env.SESSION_SECRET.length >= 32 ? "valid" : "too_short";
}
export const SESSION_HOURS = 12;
export function signSession({ userId, tenantId }) {
  const secret = sessionSecret();
  if (!secret) throw new Error("SESSION_SECRET is missing or shorter than 32 characters");
  const token = jwt.sign({ typ: "session", sub: userId, tenant_id: tenantId }, secret, { algorithm: "HS256", expiresIn: `${SESSION_HOURS}h` });
  return { token, expiresAt: new Date(Date.now() + SESSION_HOURS * 3600 * 1000).toISOString() };
}

// A short-lived pass between the two sign-in steps. It proves the password was
// right and nothing else: it can't be used as a session.
export function signChallenge(kind, { sub, tenantId }, minutes) {
  const secret = sessionSecret();
  if (!secret) throw new Error("SESSION_SECRET is missing or shorter than 32 characters");
  return jwt.sign({ typ: kind, sub, ...(tenantId ? { tenant_id: tenantId } : {}) }, secret, { algorithm: "HS256", expiresIn: `${minutes}m` });
}
export function verifyChallenge(token, kind) {
  const secret = sessionSecret();
  if (!secret || !token) return null;
  try {
    const p = jwt.verify(String(token).replace(/\s+/g, ""), secret, { algorithms: ["HS256"] });
    return p.typ === kind ? p : null;
  } catch (err) {
    return null;
  }
}

// Platform administrators: a separate kind of session, shorter-lived, that
// only the /platform routes accept (and that the company routes refuse).
export const PLATFORM_SESSION_HOURS = 2;
export function signPlatformSession(adminId) {
  const secret = sessionSecret();
  if (!secret) throw new Error("SESSION_SECRET is missing or shorter than 32 characters");
  const token = jwt.sign({ typ: "platform", sub: adminId }, secret, { algorithm: "HS256", expiresIn: `${PLATFORM_SESSION_HOURS}h` });
  return { token, expiresAt: new Date(Date.now() + PLATFORM_SESSION_HOURS * 3600 * 1000).toISOString() };
}

// Platform routes call this; company routes never accept the token it checks.
export function verifyPlatformToken(token) {
  return verifyChallenge(String(token ?? "").replace(/^Bearer /, ""), "platform");
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function lookupUser(tenantId, userId) {
  // Scoped to the claimed agency: a real user presenting another
  // agency's tenant_id finds nothing, because row-level security hides
  // users that aren't theirs.
  return withTenant(tenantId, async (client) =>
    (await client.query(
      `SELECT u.role, u.extra_roles::text[] AS extra_roles, u.is_active AS user_active, t.is_active AS tenant_active,
              (SELECT cm.field_level FROM crew_members cm WHERE cm.user_id = u.user_id
                 ORDER BY (cm.field_level IS NULL) LIMIT 1) AS field_level
       FROM users u JOIN tenants t ON t.tenant_id = u.tenant_id
       WHERE u.user_id = $1 AND u.tenant_id = $2`,
      [userId, tenantId]
    )).rows[0]
  );
}

// The ONE place a token becomes a user. The HTTP middleware and the
// WebSocket handshake both use it — two copies of "verify the token" is
// how one of them ends up checking less than the other.
//
// Every refusal carries the same message on purpose: a caller shouldn't
// learn whether an account exists, is deactivated, or belongs to a
// suspended agency. The specific reason goes in the audit log instead.
export async function resolveSession(token) {
  const refused = { error: "Invalid or expired session" };
  if (!token) return { error: "Missing session token" };
  let payload;
  try {
    const clean = token.replace(/\s+/g, "");
    const alg = jwt.decode(clean, { complete: true })?.header?.alg;
    if (alg === "HS256") {
      const secret = sessionSecret();
      if (!secret) throw new Error("SESSION_SECRET is not set");
      payload = jwt.verify(clean, secret, { algorithms: ["HS256"] });
      // Only a finished sign-in is a session. A password-step pass or a
      // platform token must never open a company's data.
      if (payload.typ !== "session") throw new Error("not a session token");
    } else {
      payload = jwt.verify(clean, normalizeKey(process.env.JWT_PUBLIC_KEY), { algorithms: ["RS256"] });
    }
  } catch (err) {
    // The caller only ever sees the generic message; the real reason goes to the server log.
    console.error("session token rejected:", err.message);
    return refused;
  }
  // Both become UUID-typed values in the database. A malformed claim
  // should be a clean refusal here, not an opaque 500 from deep in a
  // query — or an unattributable write.
  if (!UUID_RE.test(payload.sub ?? "") || !UUID_RE.test(payload.tenant_id ?? "")) return refused;

  const who = { tenantId: payload.tenant_id, userId: payload.sub };
  const row = await lookupUser(who.tenantId, who.userId);
  const deny = (reason) => ({ ...refused, denied: { who, reason } });
  if (!row) return deny("no such user in this agency");
  if (!row.tenant_active) return deny("agency suspended");
  if (!row.user_active) return deny("user deactivated");
  return { user: { ...who, role: row.role, roles: [row.role, ...(row.extra_roles || [])], fieldLevel: row.field_level || null } };
}

export async function requireAuth(req, res, next) {
  // Several routers each mount this; the first to run has already
  // authenticated the request, and repeating a database lookup per
  // router would multiply its cost for nothing.
  if (req.user) return next();
  const session = await resolveSession(req.headers.authorization?.replace("Bearer ", ""));
  if (!session.user) {
    if (session.denied) {
      try {
        await auditDenied(session.denied.who, { method: req.method, path: req.originalUrl, reason: session.denied.reason });
      } catch (err) {
        // A claimed agency that doesn't exist has nothing to attach the
        // entry to. The caller is refused either way.
      }
    }
    return res.status(401).json({ error: session.error });
  }
  req.user = session.user;
  // Everything downstream, including the database layer, can now ask who
  // is acting without it being passed through every call.
  requestContext.run({ userId: session.user.userId }, next);
}

// "Can you see this row" is the database's job; "are you allowed to take
// this action at all" is this. The role it checks is the one the
// database just returned, not the one the token claimed. A refusal is
// logged: someone with a valid session reaching past their role is worth
// knowing about.
export function requireRole(...allowedRoles) {
  return async (req, res, next) => {
    // A person can hold several roles; any one of them is enough.
    if ((req.user.roles || [req.user.role]).some((r) => allowedRoles.includes(r))) return next();
    try {
      await auditDenied(req.user, {
        method: req.method,
        path: req.originalUrl,
        requiredRoles: allowedRoles,
        actualRole: req.user.role,
        actualRoles: req.user.roles,
      });
    } catch (err) {
      // The caller is being refused either way — don't let a logging
      // failure turn a 403 into a 500, but don't swallow it silently.
      console.error("could not record a denied attempt:", err.message);
    }
    return res.status(403).json({ error: "Not authorized for this action" });
  };
}
